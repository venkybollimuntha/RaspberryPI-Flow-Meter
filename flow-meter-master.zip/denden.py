import try_analog_input

set_to_get = try_analog_input.fGPIOUpdate(ss)
print(set_to_get)
